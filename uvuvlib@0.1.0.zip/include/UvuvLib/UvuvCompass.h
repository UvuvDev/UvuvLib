




class UvuvCompass { // Position tracking and such
private:

protected:

public:


};